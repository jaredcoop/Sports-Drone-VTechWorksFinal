import os

d = {}

def correctFrameNum(frame):
	global d

	totalDecrement = 0
	for cut in d:
		if frame > cut:
			totalDecrement += d[cut]

	return frame - totalDecrement

# returns the cuts needed to make split video
def updateStats():
	global d

	edl = open('edl.txt', 'r')
	statsFile = open('stats.txt', 'r')

	cuts = [s.strip() for s in edl.readlines()]
	stats = [s.strip().split() for s in statsFile.readlines()]

	print(cuts)

	cuts = [int(s.split()[1]) for s in cuts]

	# print(cuts)

	if len(cuts) % 2 == 1:
		cuts.pop()

	# print(cuts)

	for i in range(0, len(cuts), 2):
		diff = cuts[i+1] - cuts[i]
		d[cuts[i]] = diff

	# print(d)

	print(stats)

	correctedStats = open('corrStats.txt', 'w')


	for stat in stats:
		orig = int(stat[-1])
		new = str(correctFrameNum(orig))
		stat[-1] = new

		for i in range(len(stat)-1):
			word = stat[i]
			correctedStats.write(word + ' ')
		correctedStats.write(stat[-1] + '\n')

	edl.close()
	os.remove('edl.txt')
	statsFile.close()
	correctedStats.close()

	pairedCuts = []
	for i in range(0, len(cuts), 2):
		pairedCuts.append((cuts[i], cuts[i+1]))

	print(pairedCuts)
	print("from updateStats")
	return pairedCuts







