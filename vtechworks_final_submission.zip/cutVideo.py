import cv2
import time

def createCutVideo(cuts):

	print("Exporting Cut Video...")
	print(cuts)

	start_time = time.time()

	vidcap = cv2.VideoCapture('clip1.mp4')
	success,image = vidcap.read()

	height, width, channels = image.shape
	fourcc = cv2.VideoWriter_fourcc(*'mp4v')
	out = cv2.VideoWriter('cutVideo.mp4', fourcc, 30, (width, height))

	numFrame = 0
	while success:
		numFrame += 1

		include = True

		for low, upper in cuts:
			if numFrame < low:
				continue
			elif numFrame >= low and numFrame <= upper:
				include = False

		cv2.putText(image, str(numFrame), (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 1, cv2.LINE_AA)
		# cv2.putText(image, str(include), (150, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 1, cv2.LINE_AA)

		if include:
			out.write(image)

		# cv2.imshow('Match Detection',image)
		# if cv2.waitKey(1) & 0xFF == ord('q'):
		# 	break
		success,image = vidcap.read()

	vidcap.release()
	cv2.destroyAllWindows()

	print("Cut video in %s seconds..." % (time.time() - start_time))