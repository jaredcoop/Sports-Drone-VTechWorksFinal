import os
import cv2
import time
import re
import argparse

#export highlights command line argument
ap = argparse.ArgumentParser()

ap.add_argument("-e", "--export", type=bool, default=True, required=False,
	help="Boolean flag to export highlight clips")

args = vars(ap.parse_args())

#create highlights method
def createHighlight(endFrame, videoPath):
    print("Exporting Highlight.....: " + videoPath)
    start_time = time.time()

    vidcap = cv2.VideoCapture('cutVideo.mp4')
    success,image = vidcap.read()

    height, width, channels = image.shape
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(videoPath, fourcc, 30, (width, height))

    startFrame = endFrame - 300
    numFrame = 0
    while success:
        numFrame += 1

        include = False

        
        if numFrame >= startFrame and numFrame <= endFrame:
            include = True
        

        cv2.putText(image, str(numFrame), (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 1, cv2.LINE_AA)
        # cv2.putText(image, str(include), (150, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 1, cv2.LINE_AA)

        if include:
            out.write(image)

        # cv2.imshow('Match Detection',image)
        # if cv2.waitKey(1) & 0xFF == ord('q'):
        # 	break
        success,image = vidcap.read()

    vidcap.release()
    cv2.destroyAllWindows()

    print("Cut highlight in %s seconds... \n" % (time.time() - start_time))

#Players Folder name
parent_directory = "Players"
mode = 0o666
#check if that folder already exists
if not os.path.exists(parent_directory):
    os.mkdir(parent_directory, mode)

#open roster file
rosterFile = open("roster.txt", 'r')
roster = rosterFile.readlines()

#open corrected stats file
statsFile = open("corrStats.txt", 'r')
stats = statsFile.readlines()

#regular expression used for frame pull out
frameReg = re.compile('\d+')

#loop through players
for player in roster:
    #create player subfolder
    player_directory = player.strip()
    path = os.path.join(parent_directory, player_directory)
    if not os.path.exists(path):
        os.mkdir(path, mode)

    #create stats text file in player directory
    stat_path = os.path.join(path, player.strip() + "_stats.txt")
    currentPlayerStats = ""
    #open the player stat file to see if stats are already currently in the file
    if os.path.exists(stat_path):
        playerStatFile = open(stat_path, 'r')
        currentPlayerStats = playerStatFile.read()
        playerStatFile.close()

    playerStatFile = open(stat_path, 'a')
    #loop through stats in stats file
    for stat in stats:
        #does the current stat involve current player
        if player.strip().lower() in stat.lower():
            #if the stat file does not currently contain  (eliminate duplicate stats)
            if stat.strip() not in currentPlayerStats:
                playerStatFile.write(stat.strip() + "\n")
        
            
            #create highlight video
            if (args["export"]):
                endFrame = frameReg.findall(stat)
                stat_striped = stat.replace(endFrame[0], "").replace(" ", "_")
                videoPath = os.path.join(path, stat_striped.strip() + ".mp4")
                createHighlight(int(endFrame[0]), videoPath)

    
    
    #close the stat file
    playerStatFile.close()
    

