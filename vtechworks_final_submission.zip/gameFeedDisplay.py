#Import libraries
import cv2
import os
import numpy as np
import imutils

image = None
vidcap = None
homeScore = 0
homeTeam = "Home Team"
awayScore = 0
awayTeam = "Away Team"
autoTrack = False
numLoop = 0

def getFrame():
	return numLoop

def execute_play_detection():
	global image, vidcap, numLoop
	#Reading the video
	vidcap = cv2.VideoCapture('clip1.mp4')
	success,image = vidcap.read()

	#Read the video frame by frame
	while success:
		numLoop+=1

		#FROM APPLICATION GUI
		displayScoreboard()

		cv2.imshow('Match Detection',image)
		cv2.waitKey(20)
		success,image = vidcap.read()
		
	vidcap.release()
	cv2.destroyAllWindows()

def forceQuit():
	vidcap.release()
	cv2.destroyAllWindows()

def displayScoreboard():
	global homeScore, homeTeam, awayScore, awayTeam
	height, width, c = image.shape
	scoreboard = str(homeScore) + " - " + homeTeam + "  vs  " + awayTeam + " - " + str(awayScore)
	textsize = cv2.getTextSize(scoreboard, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
	textX = (image.shape[1] - textsize[0]) / 2
	textY = (image.shape[0] -  textsize[1])
	cv2.putText(image, scoreboard, (round(textX) + 25, round(textY)), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2, cv2.LINE_AA)

def updateScoreboard(hTeam, aTeam, hScore, aScore):
	global homeScore, homeTeam, awayScore, awayTeam
	homeScore = hScore
	homeTeam = hTeam
	awayScore = aScore
	awayTeam = aTeam