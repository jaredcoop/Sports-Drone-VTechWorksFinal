import os
import cv2
import time


#Open up the EDL file
edlFile = open('edl.txt', 'r')
edlCommands = edlFile.readlines()

#Open up Video File
vidcap = cv2.VideoCapture('cutVideo.mp4')
success,image = vidcap.read()

height, width, channels = image.shape
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
videoPath = "finalVideo.mp4"
out = cv2.VideoWriter(videoPath, fourcc, 30, (width, height))

#timer
start_time = time.time()

#main logic loop
numFrame = 0
edits = ["","","",""]
while success:
    numFrame += 1
    if (len(edlCommands) > numFrame):
        edits = edlCommands[numFrame].split(",")
        minX = int(edits[0].strip())
        maxX = int(edits[1].strip())
        minY = int(edits[2].strip())
        maxY = int(edits[3].strip())

  
    
        if minX < 0:
            minX = 0
        if minY < 0:
            minY = 0
    
        #crop the video
    croppedFrame = image[minY:maxY, minX:maxX]
    resized = cv2.resize(croppedFrame, (width, height))

    #write to output video
    out.write(resized)

    #cv2.imshow('Match Detection',image)
    #cv2.imshow('Cropped',resized)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    success,image = vidcap.read()


print("Video Processed in %s seconds... \n" % (time.time() - start_time))

#release video clip
vidcap.release()
cv2.destroyAllWindows()