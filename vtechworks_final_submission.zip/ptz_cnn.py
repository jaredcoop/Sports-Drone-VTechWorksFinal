#Import libraries
import cv2
import os
import numpy as np
import imutils
from fieldBound_util import FieldBound
from ptz_util import PTZ
from centermass_util import CenterMass
import argparse
import tensorflow as tf
from tensorflow import keras
from keras.models import Sequential
from keras.layers import Dense, Flatten, Conv2D, MaxPooling2D, Dropout
from tensorflow.keras import layers
from keras.utils import to_categorical
from skimage.transform import resize

##################################################################
def find_contours(image):
    #converting into hsv image
    hsv = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
    #green range
    lower_green = np.array([40,40, 40])
    upper_green = np.array([70, 255, 255])

    #white range
    lower_white = np.array([0,0,0])
    upper_white = np.array([0,0,255])

    #Define a mask ranging from lower to uppper
    mask = cv2.inRange(hsv, lower_green, upper_green)
    #Do masking
    res = cv2.bitwise_and(image, image, mask=mask)
    #convert to hsv to gray
    res_bgr = cv2.cvtColor(res,cv2.COLOR_HSV2BGR)
    res_gray = cv2.cvtColor(res,cv2.COLOR_BGR2GRAY)

    #Defining a kernel to do morphological operation in threshold image to 
    #get better output.
    kernel = np.ones((13,13),np.uint8)
    thresh = cv2.threshold(res_gray,127,255,cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    #find contours in threshold image     
    contours,hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    return contours

##################################################################
ap = argparse.ArgumentParser()
ap.add_argument("-v", "--video", required=True,
	help="name of video clip to use, in Videos folder")
ap.add_argument("-m", "--model", required=True,
    help="name of saved model to user, in ML/saved_model/ folder")
args = vars(ap.parse_args())

clipName = args['video']
modelName = args['model']
##################################################################
#READING / VIDEO PROCESSING
vidcap = cv2.VideoCapture('Videos/' + clipName + '.mp4') #change video file here
success,image = vidcap.read()

height, width, channels = image.shape
numLoop = 0

fieldBound = FieldBound()
ptz = PTZ(width, height)
centerMass = CenterMass(width, height)

##################################################################
#LOAD NN MODEL
model = keras.models.load_model("ML/saved_model/" + modelName)
##################################################################

#MAIN WHILE LOOP FOR PROCESSING
#Read the video frame by frame
while success:
    #PAN TILT ZOOM
    minX, maxX, minY, maxY = ptz.ptz(image, (centerMass.X, centerMass.Y))
    thirdWidthCropped, thirdHeightCropped = (maxX-minX)//3 , (maxY-minY)//3

    # IF GETTING ~!ssize.empty() ERROR, the min/max X/Y are out of bounds (check zoomScale)
    # The zoomScale + int rounding causes bounds to go negative
    croppedFrame = image[minY:maxY, minX:maxX]
    resized = cv2.resize(croppedFrame, (width, height))

    ##################################################################
    #BOUNDARY / FIELD POSITION
    fieldContourSet, fieldContour = fieldBound.draw_bounds(image) # add param 'True' to see fieldContour
    cv2.setMouseCallback('Feed', fieldBound.mouse_click)

    #DRAWING BOUNDARY BOX
    ##################################################################
    numLoop+=1

    if fieldContourSet:
        #find the contours on the image
        contours = find_contours(image)

        font = cv2.FONT_HERSHEY_SIMPLEX

        for i, c in enumerate(contours):
            
            x,y,w,h = cv2.boundingRect(c)
            if (fieldContour[y][x] != (0, 255, 0))[1]:
                continue
            #grab 40x20 around player 
            contour_img = image[y:y+h,x:x+w]
            if w <= 20 or h <= 40:
                y_mid = int(y + (h/2))
                x_mid = int(x + (w/2))
                contour_img = image[(y_mid - 20):(y_mid + 20), (x_mid - 10):(x_mid + 10)]
                cv2.rectangle(image,(x_mid-10,y_mid-20),(x_mid+10,y_mid+20),(0,0,255),3)
            elif w <= 30 and h <= 60:
                contour_img = resize(contour_img, (40, 20, 3))
                
                cv2.rectangle(image,(x_mid-10,y_mid-20),(x_mid+10,y_mid+20),(0,0,255),3)
            else:
                continue
            #let the model make a prediction
            # model_prediction = model.predict(np.array([contour_img]))
            # predict_list = (model_prediction.tolist())[0]
            # is_player = (predict_list[0] < predict_list[1])
            is_player = False
            
            #Detect players
            if is_player and (w < 60):
                
                centerMass.gather(x, y, w, h)
                
                cv2.putText(image, 'Player', (x-2, y-2), font, 0.8, (0,0,255), 1, cv2.LINE_AA)
                cv2.rectangle(image,(x,y),(x+w,y+h),(0,0,255),3)
                
            # every 10th frame, update Center of Mass
            if  numLoop % 10 == 0 and centerMass.numContours > 0 and i == len(contours)-1:
                centerMass.update()

    ptz.showGraphics(image, (centerMass.X, centerMass.Y))
    
    cv2.imshow('crop', resized)
    cv2.imshow('Feed',image)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    if not fieldContourSet: success,image = vidcap.read()
    ##################################################################

##################################################################
#destory all windows and exit execution
vidcap.release()
cv2.destroyAllWindows()
##################################################################
