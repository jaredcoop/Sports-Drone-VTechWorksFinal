# set the matplotlib backend so figures can be saved in the background
import matplotlib
matplotlib.use("Agg")
# import the necessary packages
from stridednet import StridedNet
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2
from imutils import paths
import matplotlib.pyplot as plt
import numpy as np
import argparse
import cv2
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
# ap.add_argument("-d", "--dataset", required=True,
# 	help="path to input dataset")
ap.add_argument("-x", "--xData", required=True,
	help="path to images")
ap.add_argument("-y", "--yData", required=True,
	help="path to labels")
ap.add_argument("-e", "--epochs", type=int, default=50,
	help="# of epochs to train our network for")
ap.add_argument("-p", "--plot", type=str, default="plot.png",
	help="path to output loss/accuracy plot")
ap.add_argument("-s", "--saveModel", type=str, default='',
	help="path to save CNN Model")
args = vars(ap.parse_args())

# initialize the set of labels from the CALTECH-101 dataset we are
# going to train our network on
LABELS = set([1, 0])
# grab the list of images in our dataset directory, then initialize
# the list of data (i.e., images) and class images
print("[INFO] loading images...")
import_images = np.load(args["xData"])
import_labels = np.load(args["yData"])
data = []
labels = []

# import_labels = np.where(import_labels==1, "Player", import_labels)

# import_labels = np.where(import_labels=='0', "NotPlayer", import_labels)

if len(import_images) != len(import_labels):
	print('NOT SAME LENGTH')
# loop over the image paths
for i, img in enumerate(import_images):
	# extract the class label from the filename
	label = import_labels[i]
	# if the label of the current image is not part of of the labels
	# are interested in, then ignore the image
	if label not in LABELS:
		continue
	# load the image and resize it to be a fixed 96x96 pixels,
	# ignoring aspect ratio
	image = import_images[i]
	# image = cv2.resize(image, (40, 40))
	# update the data and labels lists, respectively
	data.append(image)
	if label == 1:
		labels.append(np.array([1, 0]))
	else:
		labels.append(np.array([0, 1]))

labels = np.array(labels)


# convert the data into a NumPy array, then preprocess it by scaling
# all pixel intensities to the range [0, 1]
data = np.array(data, dtype="float") / 255.0

(trainX, testX, trainY, testY) = train_test_split(data, labels,
	test_size=0.25, stratify=labels, random_state=42)

# construct the training image generator for data augmentation
aug = ImageDataGenerator(rotation_range=20, zoom_range=0.15,
	width_shift_range=0.2, height_shift_range=0.2, shear_range=0.15,
	horizontal_flip=True, fill_mode="nearest")

# initialize the optimizer and model
print("[INFO] compiling model...")
opt = Adam(lr=1e-4, decay=1e-4 / args["epochs"])
model = StridedNet.build(width=20, height=40, depth=3,
	classes=2, reg=l2(0.0005))
model.compile(loss="categorical_crossentropy", optimizer=opt,
	metrics=["accuracy"])
# train the network
print("[INFO] training network for {} epochs...".format(
	args["epochs"]))
print(trainX.shape)
print(trainY.shape)
H = model.fit(x=aug.flow(trainX, trainY, batch_size=32),
	validation_data=(testX, testY), steps_per_epoch=len(trainX) // 32,
	epochs=args["epochs"])

# evaluate the network
print("[INFO] evaluating network...")
predictions = model.predict(x=testX, batch_size=32)
print(classification_report(testY.argmax(axis=1),
	predictions.argmax(axis=1), target_names=np.array(['0', '1'])))

# plot the training loss and accuracy
N = args["epochs"]
plt.style.use("ggplot")
plt.figure()
plt.plot(np.arange(0, N), H.history["loss"], label="train_loss")
plt.plot(np.arange(0, N), H.history["val_loss"], label="val_loss")
plt.plot(np.arange(0, N), H.history["accuracy"], label="train_acc")
plt.plot(np.arange(0, N), H.history["val_accuracy"], label="val_acc")
plt.title("Training Loss and Accuracy on Dataset")
plt.xlabel("Epoch #")
plt.ylabel("Loss/Accuracy")
plt.legend(loc="lower left")
plt.savefig(args["plot"])

manTest = input("\nDo you wish to test this model with select pictures? (y/n) ")
if manTest == 'y':
	import glob
	foldPath = input("\nType the path of the folder with the .npy pictures you wish to open: ")
	files = glob.glob(foldPath + '/*.npy')

	for pic in files:
		loadPic = np.load(pic)
		loadPic = np.array(loadPic, dtype="float") / 255.0
		predictions = model.predict(np.array([loadPic]))
		predict = predictions.tolist()[0]
		isPlayer = "Yes Player" if predict[0] > predict[1] else "No Player"

		enlarged = cv2.resize(loadPic, (loadPic.shape[1]*10, loadPic.shape[0]*10))
		cv2.putText(enlarged,isPlayer,(0,18), cv2.FONT_HERSHEY_SIMPLEX, .7,(0,255,255),2,cv2.LINE_AA)
		cv2.putText(enlarged,str(round(predict[0]*100, 2)) + "% Player",(0,38), cv2.FONT_HERSHEY_SIMPLEX, .7,(20,255,0),2,cv2.LINE_AA)
	
		key = -1
		while True:
		    cv2.imshow('img', enlarged)
		    key = cv2.waitKey(1)
		    if  key == 32:
		        break
		    elif key == ord('q'):
		        break
		if key == ord('q'):
			break


# Save the model - if working with new model
if args['saveModel'] == "":
    save = input("\nDo you wish to save this model? (y/n) ")
    if save == "y":
        duplicate = 1
        notes = input("\nA word or two on performance of model: ")
        notes = notes.replace(" ", "") 
        model_file_name = "saved_model/stridedModel_" + notes + "_"
        while os.path.exists(model_file_name + str(duplicate)):
            duplicate += 1
        model_file_name += str(duplicate)
        print("Saving " + model_file_name)
        model.save(model_file_name)

print("\nExiting...")