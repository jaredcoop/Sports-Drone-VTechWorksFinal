#Import libraries
import cv2
import os
import numpy as np
import imutils
import random
import copy
from glob import glob
import argparse
import sys

ap = argparse.ArgumentParser()
# ap.add_argument("-d", "--dataset", required=True,
# 	help="path to input dataset")
ap.add_argument("-x", "--xData", required=True,
	help="path to xData Folder")
ap.add_argument("-y", "--yData", required=True,
	help="path to yData Folder")
args = vars(ap.parse_args())


xData = glob(args["xData"] + '/*.npy')
xData.sort()
yData = glob(args["yData"] + '/*.npy')
yData.sort()

completeX, completeY = [], []

for xFile in xData:
    print(xFile)
    loadedX = np.load(xFile)
    #cv2.imshow("TestX", loadedX[])
    completeX.extend(loadedX)

for yFile in yData:
    print(yFile)
    loadedY = np.load(yFile)
    completeY.extend(loadedY)

# complete X is wrong
completeX = np.array(completeX)
completeY = np.array(completeY)
print(completeX.shape)
print(len(completeY))

aggNum = 1
while os.path.exists('Aggregated/x_agg' + str(aggNum) + '.npy'):
    aggNum += 1

np.save('Aggregated/x_agg' + str(aggNum) + '.npy', np.array(completeX))
np.save('Aggregated/y_agg' + str(aggNum) + '.npy', np.array(completeY))
