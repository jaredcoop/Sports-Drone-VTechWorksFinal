#Import libraries
import cv2
import os
import numpy as np
import imutils
import random
import copy
import glob
import argparse
import sys

ap = argparse.ArgumentParser()
ap.add_argument("-v", "--video", required=True,
	help="name of video clip to use, in Videos folder")
args = vars(ap.parse_args())

##################################################################
#READING / VIDEO PROCESSING
clipName = args['video']
print("Opening..." + clipName)
vidcap = cv2.VideoCapture(clipName) #change video file here
success,image = vidcap.read()
copyImg = copy.deepcopy(image)

# ensure file save paths are good
# xPath = args['xData']
# yPath = args['yData']
# if os.path.isdir(xPath) or os.path.exists(xPath+'.npy'):
#     sys.exit('\nERROR: xData file path already exists\n')
# elif os.path.isdir(yPath) or os.path.exists(yPath+'.npy'):
#     sys.exit('\nERROR: yData file path already exists\n')

height, width, channels = image.shape

imgList = []
labelsList = []

isPlayerList = []
notPlayerList = []
numIsPlayer = 0
numNotPlayer = 0
framesElapsed = 0
selections = []

SAMP_WIDTH, SAMP_HEIGHT = 20, 40
w2, h2 = int(SAMP_WIDTH/2), int(SAMP_HEIGHT/2)

def isInBounds(x, y):
    return x > 0 + w2 and x < width - w2 and y > 0 + h2 and y < height - h2

def mouse_click(event, x, y, flags, params): 

    global imgList
    global labelsList
    global isPlayerList
    global notPlayerList
    global selections
    global numIsPlayer
    global numNotPlayer
    
    if event == cv2.EVENT_LBUTTONDOWN and isInBounds(x, y):
        numIsPlayer += 1
        player = copyImg[y-h2:y+h2,x-w2:x+w2]
        imgList.append(player)
        labelsList.append(1)
        isPlayerList.append((x, y))
        selections.append(1)
        image[40:90,0:300] = copyImg[40:90,0:300]
        

    if event == cv2.EVENT_RBUTTONDOWN and isInBounds(x, y):
        numNotPlayer += 1
        notPlayer = copyImg[y-h2:y+h2,x-w2:x+w2]
        imgList.append(notPlayer)
        labelsList.append(0)
        notPlayerList.append((x, y))
        selections.append(0)
        image[40:90,0:300] = copyImg[40:90,0:300]

def remove_last_selection():
    
    global imgList
    global labelsList
    global isPlayerList
    global notPlayerList
    global selections
    global image
    global copyImg
    global numIsPlayer
    global numNotPlayer

    if len(selections) == 0:
        print('No selections have been made')
    elif selections[-1] == 1:
        numIsPlayer -= 1
        selections.pop()
        x, y = isPlayerList.pop()
        imgList.pop()
        labelsList.pop()
        # slightly bigger to include rectangle
        image[y-h2:y+h2+2,x-w2:x+w2+2] = copyImg[y-h2:y+h2+2,x-w2:x+w2+2]
        image[40:90,0:300] = copyImg[40:90,0:300]
    else:
        numNotPlayer -= 1
        selections.pop()
        x, y = notPlayerList.pop()
        imgList.pop()
        labelsList.pop()
        image[y-h2:y+h2+2,x-w2:x+w2+2] = copyImg[y-h2:y+h2+2,x-w2:x+w2+2]
        image[40:90,0:300] = copyImg[40:90,0:300]
        

#MAIN WHILE LOOP FOR PROCESSING
#Read the video frame by frame
while success:

    cv2.setMouseCallback('Feed', mouse_click)

    for x, y in isPlayerList:
        cv2.rectangle(image,(x-w2,y-h2),(x+w2,y+h2),(255,0,0),1)
    for x, y in notPlayerList:
        cv2.rectangle(image,(x-w2,y-h2),(x+w2,y+h2),(0,0,255),1)

    cv2.putText(image, 'Frames Elapsed:  ' + str(framesElapsed), (2,18), cv2.FONT_HERSHEY_SIMPLEX, .7, (0,255,255), 1,cv2.LINE_AA)
    cv2.putText(image, 'Seconds Elapsed: ' + str(framesElapsed/30), (2,40), cv2.FONT_HERSHEY_SIMPLEX, .7, (0,255,255), 1,cv2.LINE_AA)
    cv2.putText(image, 'Is Player Samp:  ' + str(numIsPlayer), (2,62), cv2.FONT_HERSHEY_SIMPLEX, .7, (50,255,0), 1,cv2.LINE_AA)
    cv2.putText(image, 'Not Player Samp: ' + str(numNotPlayer), (2,84), cv2.FONT_HERSHEY_SIMPLEX, .7, (50,255,0), 1,cv2.LINE_AA)
    cv2.imshow('Feed',image)
    
    key = cv2.waitKey(1)
    if  key == ord('q'):
        break
    elif key == 32: # SPACE BAR
        remove_last_selection()
    elif key == ord('a'):
        for i in range(15):
            success,image = vidcap.read()
            if not success:
                break
        copyImg = copy.deepcopy(image)
        framesElapsed += 15
        isPlayerList.clear()
        notPlayerList.clear()
        selections.clear()
    elif key == ord('s'):
        for i in range(30):
            success,image = vidcap.read()
            if not success:
                break
        copyImg = copy.deepcopy(image)
        framesElapsed += 30
        isPlayerList.clear()
        notPlayerList.clear()
        selections.clear()
    elif key == ord('d'):
        for i in range(60):
            success,image = vidcap.read()
            if not success:
                break
        copyImg = copy.deepcopy(image)
        framesElapsed += 60
        isPlayerList.clear()
        notPlayerList.clear()
        selections.clear()
    elif key == ord('f'):
        for i in range(150):
            success,image = vidcap.read()
            if not success:
                break
        copyImg = copy.deepcopy(image)
        framesElapsed += 150
        isPlayerList.clear()
        notPlayerList.clear()
        selections.clear()

##################################################################

# check if selection working properly
# print(labelsList) 

idx = 0
while True:
    player = imgList[idx]
    resized = cv2.resize(player, (player.shape[1]*8, player.shape[0]*8))
    label = 'Not Player' if labelsList[idx] == 0 else 'Player'
    cv2.putText(resized,label,(0,18), cv2.FONT_HERSHEY_SIMPLEX, .7,(0,69,255),2,cv2.LINE_AA)
    cv2.imshow("lol", resized)
    key = cv2.waitKey(1)
    if  key == ord('q'):
        break
    elif key == 32:
        if idx == len(imgList) - 1:
            break
        else:
            idx += 1


aggNum = 1
clipName = clipName.replace(".", "")
clipName = clipName.replace("\\", "")
clipName = clipName.replace("Videos", "")
clipName = clipName.replace("mp4", "")
xPath = "xData/x_" + clipName + f'_{aggNum}' + ".npy"
yPath = "yData/y_" + clipName + f'_{aggNum}' + ".npy"

while os.path.exists(xPath):
    aggNum += 1
    xPath = "xData/x_" + clipName + f'_{aggNum}' + ".npy"
    yPath = "yData/y_" + clipName + f'_{aggNum}' + ".npy"

np.save(xPath, np.array(imgList))
np.save(yPath, np.array(labelsList))


##################################################################
#destory all windows and exit execution
vidcap.release()
cv2.destroyAllWindows()
##################################################################
