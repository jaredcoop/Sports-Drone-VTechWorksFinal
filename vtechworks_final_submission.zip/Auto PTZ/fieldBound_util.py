#Import libraries
import cv2
import os
import numpy as np
import imutils

class FieldBound: 
    # in form of (x, y, color-value) ** going to have 4 points max
    points = []
    isAdjusting = False
    pointsSorted = False
    fieldContour = None
    upperR, upperL, lowerL, lowerR = None, None, None, None

    def mouse_click(self, event, x, y, flags, params): 
        if event == cv2.EVENT_LBUTTONDOWN:
            if self.isAdjusting:
                for num, p in enumerate(self.points):
                    px, py, pcolor = p
                    if pcolor == (0, 0, 255):
                        # changing x and y position after adjustment
                        self.points[num] = [x, y, (255, 255, 0)]
                        self.isAdjusting = False
                        self.pointsSorted = False
            else:
                if len(self.points) > 0:
                    for num, p in enumerate(self.points):
                        px, py, pcolor = p
                        if (abs(px-x)**2 + abs(py-y)**2)**0.5 < 10:
                            self.isAdjusting = True
                            self.points[num][2] = (0, 0, 255)
                if len(self.points) < 4 and not self.isAdjusting:
                    self.points.append([x,y, (255, 255, 0)])

        if event == cv2.EVENT_RBUTTONDOWN:
            # check if green
            print("Is %d, %d in the bounds? -> %s\n" %(x, y, (self.fieldContour[y][x] == (0, 255, 0))[1]))

    def byYval(val):
        return val[1]

    def draw_bounds(self, image, show=False):  

        for p in self.points:
            x, y, color = p
            cv2.circle(image, (x, y), 10, color, -1)

        if len(self.points) == 4 and not self.pointsSorted:

            # Sorting points array by Y position
            self.points.sort(key=FieldBound.byYval)

            self.upperL = (self.points[0][0], self.points[0][1])
            self.upperR = (self.points[1][0], self.points[1][1])
            self.lowerL = (self.points[2][0], self.points[2][1])
            self.lowerR = (self.points[3][0], self.points[3][1])

            # Swapping upper and lower by X position if needed
            if self.points[0][0] > self.points[1][0]:
                self.upperL = (self.points[1][0], self.points[1][1])
                self.upperR = (self.points[0][0], self.points[0][1])

            if self.points[2][0] > self.points[3][0]:
                self.lowerL = (self.points[3][0], self.points[3][1])
                self.lowerR = (self.points[2][0], self.points[2][1])

            self.pointsSorted = True
            
        # Draw lines when there are 4 corner points selected
        if len(self.points) == 4:
            height, width, channels = image.shape
            pts = np.array([self.upperR, self.upperL, self.lowerL, self.lowerR], np.int32) 
            pts = pts.reshape((-1, 1, 2)) 
            cv2.polylines(image, [pts], True, (255, 255, 0), 5)
            blackBackground = np.zeros((height, width, 3), np.uint8)
            self.fieldContour = cv2.drawContours(blackBackground, [pts], -1, (0,255,0), cv2.FILLED)
            if show:
                cv2.imshow('Contour', self.fieldContour)
    
            # bool fieldContourSet, image fieldContour
            return (True, self.fieldContour)
        else:
            return (False, None)
