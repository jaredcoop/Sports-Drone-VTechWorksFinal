import cv2
import os
import numpy as np
import imutils

class CenterMass:

    totalX, totalY = 0, 0
    numContours = 0

    # Position of Center of Mass
    X, Y = -1, -1

    def __init__(self, width, height):
        self.X = int(width/2)
        self.Y = int(height/2)
    
    def gather(self, x, y, w, h, modifier=1.05):
        # Total XY mass of players
        self.totalX+= (x+(w/2))
        # Modifier to favor a lower center of mass
        self.totalY+= (y+(h/2))**modifier
        self.numContours += 1

    def update(self):
        self.X = (int(self.totalX/self.numContours))
        self.Y = (int(self.totalY/self.numContours))
        self.totalX = 0
        self.totalY = 0
        self.numContours = 0

        return (self.X, self.Y)