import cv2
import os
import numpy as np
import imutils

class PTZ:

    width, height = -1, -1
    centerFrameX, centerFrameY = -1, -1
    radiusFrameX, radiusFrameY = -1, -1
    minX, maxX = -1, -1
    minY, maxY = -1, -1
    zoomScale = 1

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.centerFrameX, self.centerFrameY = int(self.width/2),int(self.height/2)
        self.radiusFrameX, self.radiusFrameY = int((self.width/2)),int((self.height/2))
        self.minX, self.maxX = self.centerFrameX - self.radiusFrameX, self.centerFrameX + self.radiusFrameX
        self.minY, self.maxY = self.centerFrameY - self.radiusFrameY, self.centerFrameY + self.radiusFrameY
        self.zoomScale = 1

    # IF GETTING ~!ssize.empty() ERROR, the min/max X/Y are out of bounds (check zoomScale)
    # The zoomScale + int rounding causes bounds to go negative
    def ptz(self, image, centerMass):

        centerMassX, centerMassY = centerMass

        # PAN TILT ZOOM SECTION
        thirdHeightCropped = (self.maxY-self.minY)//3
        thirdWidthCropped = (self.maxX-self.minX)//3
        
        # If in top third of screen
        if centerMassY < self.minY + thirdHeightCropped:
            # PAN
            self.centerFrameY -=1
            # ZOOM
            if self.radiusFrameX > int((self.width/6)):
                self.zoomScale += 0.005
            
        # If in bottom third of screen
        if centerMassY > self.minY + thirdHeightCropped*2:
            self.centerFrameY +=1

            if self.radiusFrameX < int((self.width/2)):
                self.zoomScale -= 0.005

        # If in left third of screen
        if centerMassX < self.minX + thirdWidthCropped:
            self.centerFrameX -= 1

        # If in right third of screen
        if centerMassX > self.minX + thirdWidthCropped*2:
            self.centerFrameX +=1

        # Calculate new cropping values
        # Radius -> Zoom
        # Min/Max XY -> Panning
        self.radiusFrameX = int(self.width / (2 * self.zoomScale))
        self.radiusFrameY = int(self.height / (2 * self.zoomScale))
        self.minX, self.maxX = self.centerFrameX - self.radiusFrameX, self.centerFrameX + self.radiusFrameX
        self.minY, self.maxY = self.centerFrameY - self.radiusFrameY, self.centerFrameY + self.radiusFrameY

        return (self.minX, self.maxX, self.minY, self.maxY)

    def showGraphics(self, image, centerMass):
        thirdHeightCropped = (self.maxY-self.minY)//3
        thirdWidthCropped = (self.maxX-self.minX)//3
        centerMassX, centerMassY = centerMass
        cv2.circle(image, (centerMassX, centerMassY), 10, (0, 255, 255), -1)
        cv2.line(image,(self.minX,self.minY + thirdHeightCropped),(self.maxX, self.minY + thirdHeightCropped),(0,255,0),2)
        cv2.line(image,(self.minX,self.minY + thirdHeightCropped*2),(self.maxX, self.minY + thirdHeightCropped*2),(0,255,0),2)
        cv2.line(image,(self.minX + thirdWidthCropped,self.minY),(self.minX + thirdWidthCropped,self.maxY),(0,255,0),2)
        cv2.line(image,(self.minX + thirdWidthCropped*2,self.minY),(self.minX + thirdWidthCropped*2,self.maxY),(0,255,0),2)
        cv2.rectangle(image, (self.minX, self.minY), (self.maxX, self.maxY), (255, 0, 0), 3)