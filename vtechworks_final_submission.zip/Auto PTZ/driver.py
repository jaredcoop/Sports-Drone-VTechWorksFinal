#Import libraries
import cv2
import os
import numpy as np
import imutils
from fieldBound_util import FieldBound
from ptz_util import PTZ
from centermass_util import CenterMass

##################################################################
#READING / VIDEO PROCESSING
vidcap = cv2.VideoCapture('../cutVideo.mp4') #change video file here
success,image = vidcap.read()

height, width, channels = image.shape
numLoop = 0

fieldBound = FieldBound()
ptz = PTZ(width, height)
centerMass = CenterMass(width, height)

#Output video
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
#out = cv2.VideoWriter("ptz_video.mp4", fourcc, 30, (width, height))

##################################################################
#EDL Output
textEDL = open("edl.txt", 'w')

#MAIN WHILE LOOP FOR PROCESSING
#Read the video frame by frame
while success:
    #PAN TILT ZOOM
    minX, maxX, minY, maxY = ptz.ptz(image, (centerMass.X, centerMass.Y))
    thirdWidthCropped, thirdHeightCropped = (maxX-minX)//3 , (maxY-minY)//3

    # IF GETTING ~!ssize.empty() ERROR, the min/max X/Y are out of bounds (check zoomScale)
    # The zoomScale + int rounding causes bounds to go negative
    croppedFrame = image[minY:maxY, minX:maxX]
    resized = cv2.resize(croppedFrame, (width, height))

    #Write out to EDL
    statoutput = str(minX) + "," + str(maxX) + "," + str(minY) + "," + str(maxY) + "\n"
    textEDL.write(statoutput)
    ##################################################################
    #BOUNDARY / FIELD POSITION
    fieldContourSet, fieldContour = fieldBound.draw_bounds(image) # add param 'True' to see fieldContour
    cv2.setMouseCallback('Feed', fieldBound.mouse_click)

    #DRAWING BOUNDARY BOX
    ##################################################################
    numLoop+=1
    #converting into hsv image
    hsv = cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
    #green range
    lower_green = np.array([40,40, 40])
    upper_green = np.array([70, 255, 255])

    #white range
    lower_white = np.array([0,0,0])
    upper_white = np.array([0,0,255])

    #Define a mask ranging from lower to uppper
    mask = cv2.inRange(hsv, lower_green, upper_green)
    #Do masking
    res = cv2.bitwise_and(image, image, mask=mask)
    #convert to hsv to gray
    res_bgr = cv2.cvtColor(res,cv2.COLOR_HSV2BGR)
    res_gray = cv2.cvtColor(res,cv2.COLOR_BGR2GRAY)

    #Defining a kernel to do morphological operation in threshold image to 
    #get better output.
    kernel = np.ones((13,13),np.uint8)
    thresh = cv2.threshold(res_gray,127,255,cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)

    #find contours in threshold image     
    contours,hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    font = cv2.FONT_HERSHEY_SIMPLEX

    for i, c in enumerate(contours):
        
        x,y,w,h = cv2.boundingRect(c)
        
        #Detect players
        if (h > (1.2*w)) and (w>2) and (w < 60) and fieldContourSet and (fieldContour[y][x] == (0, 255, 0))[1]:

            player_img = image[y:y+h,x:x+w]
            player_hsv = cv2.cvtColor(player_img,cv2.COLOR_BGR2HSV)
            
            centerMass.gather(x, y, w, h)
            
            cv2.putText(image, 'Player', (x-2, y-2), font, 0.8, (0,0,255), 1, cv2.LINE_AA)
            cv2.rectangle(image,(x,y),(x+w,y+h),(0,0,255),3)
            
        # every 10th frame, update Center of Mass
        if  numLoop % 10 == 0 and centerMass.numContours > 0 and i == len(contours)-1:
            centerMass.update()

    ptz.showGraphics(image, (centerMass.X, centerMass.Y))
    
    cv2.imshow('crop', resized)
    #out.write(resized)
    cv2.imshow('Feed',image)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    success,image = vidcap.read()
    ##################################################################

##################################################################
#destory all windows and exit execution
vidcap.release()
cv2.destroyAllWindows()
##################################################################
