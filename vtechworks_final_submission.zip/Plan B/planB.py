# Notes:
# joystick recognized. num axes recognized. not doing anything.
# lots of debug statement on joystick detection need to be removed.
# all the print statements should go to a log file. For future debugging.
# v31 names to match style sheet.
# v32 test of EDL playback & linear glide & 4K
# v40 switch from numloop records to Sequence (numseq) records. Added FF RW, Scoreboard
# numseqin (inEDL file), numseqout (outEDL file)
# v40 added halfass logging. Need to switch to standard Python logging at some point
# mz-41 testing multi-file queue.
# mz-42 move loading of incoming source to main loop
# mz-43 all config values (files, etc.) moved to planb_config.json

# DO-OVER, the ability to go back in 5-second chunks to reeedit a section
# need to be fleshed out. Needs to be multiple levels of "undo", stepping
# back and reversing various actions (crop, speedup, etc.). Should be possible.

# TODO Add quit action to log.

# XXX indicates something must be urgently fixed. App may not run properly or as expected

# readme
# To record actions (crops, etc.) set playback = OFF in planb_config.json
# to playback actions using the inEDL file, change playback = ON
# for speed editing set playbackspeed to > 1 (eg 5 or 10)
# speed editing creates a log file that can then be used for playback.
# set resolution of recorded file using constant outHW
# there can be two edit_decision_list_X.json ffiles, one for input (play)
# and one for output (rec ie playback=OFF)
# toggling recording on/off is the
# is the Logitech start button (#9) Not sure it works XBOX. Also BLUE button.
# not sure XBOX triggers work.
# score change are bumpers.
# hat buttons:
# EAST = user speedup (3x, 6x, 9x). NORTH speed = 1
# SOUTH = toggle record on/off
# WEST = rewind. Doesn't really work yet 3/20.

# XXX change how numrewindframes works
# XXX add FPS ratio between record and playback
# display FPS on # DEBUG:
# move playback speed to json
# outEDL automatically incremented?
# outEDL and inEDL to config
# numgame to config

#!/usr/bin/env python
# coding: utf-8
# In[6]:

# STYLE SHEET
# eventually adhere to https://pep8.org/
# variables all lowercase
# constants start with Uppercase (variables that don't change value)
# class names are CamelStyle
# file names are snake_

# Importing libraries
import cv2
import os
import time
import datetime
import numpy as np
import imutils
import pafy
import youtube_dl
import math
import json
import sys
import pygame
import pygame.freetype

# import logging

from datetime import datetime

# if we're playing back actions from an EDL (playmode=="ON"), what's the file? inEDL.
# if we're creating a log (playmode=="OFF") actions written to 3 file edit_decision_list.json
# 3/18 now set in planb_config.json
# inEDL = "edit_decision_list_42-TUES01.json"
# outEDL = "edit_decision_list_42-WEDS12.json"

textEDL = open("edl.txt", 'w')

##########################################################
# PROCEDURES
# style: camel likeThisExample
##########################################################

def logValue(descript, arg1):
    print(f'{descript}: ', arg1)
    logfile = open('plan_b.log', 'a')
    # CK replace with standard logging
    print(f'{descript}: ', arg1, file=logfile)
    logfile.close()


def rotateImage(image, angle):
    imagecenter = tuple(np.array(image.shape[1::-1]) / 2)
    rotmat = cv2.getRotationMatrix2D(imagecenter, angle, 1.0)
    result = cv2.warpAffine(
        image, rotmat, image.shape[1::-1], flags=cv2.INTER_LINEAR)
    return result


# uses global numseqout and writeloop.
def writeValueEDL(numloop, action, value):  # CK
    global numseqout, writeloop  # CK
    outEDLData[str(numseqout)] = []  # CK
    outEDLData[str(numseqout)].append({  # CK
        'frame': numloop,  # CK
        'action': action,  # CK
        'value': value  # CK
        })  # CK
    numseqout += 1  # CK
    writeloop += 1  # CK


# get the previous Action before current numseqout.
def prevActionEDL(numseq):
    global outEDLData
    if str(numseq) in outEDLData:
        prevnumloop = outEDLData[str(numseq)][0]["frame"]
        logValue("Previous numLoop", prevnumloop)
        # DEBUG input("prevActionEDL")
        return prevnumloop
    else:
        # returns in an error.
        logValue("No previous action logged", (numseqout - 1))
        return numloop


def exitApp():
    global outEDL, numloop
    writeValueEDL(numloop, "quit", "NA")
    logValue("Job Ended: ", f'{datetime.now()}')
    with open(outEDL, 'w') as outfile:
        json.dump(outEDLData, outfile)
    quit()


def displayValue(posXY, displaytext, value):
    global screen, displayfont

    displayfont.render_to(
        screen, (posXY[0], posXY[1]), displaytext + ":", (0, 0, 0))
    displayfont.render_to(
        screen, (posXY[0] + 160, posXY[1]), str(value), (0, 0, 0))
    pygame.display.flip()


###########################################################
# Get values from planb_config.json
###########################################################

# create plan_b.log file!
logfile = open('plan_b.log', 'w')
logfile.write(f'Job Started: {datetime.now()}')
logfile.write('\n')
logfile.close()

# which game from planb_config.json is in-scope?
numgame = 0

with open('planb_config.json') as f:
    gamedata = json.load(f)

# which game from planb_config.json config is in-scope for this job?
numgame = gamedata['numgame'][0]['index']
logValue("Game to use: ", numgame)

# set variables (teams, etc) to last created record under config.
for config in gamedata['config']:
    print("Game Information: ", config['event'])

    # get source videos
for svlist in gamedata['svlist']:
    print("Config first source videos", svlist['queue'][0])

gamedetails = gamedata['config'][numgame]

# set the source video files to use
numSV = gamedata['config'][numgame]['numSV']
logValue("Num source video", numSV)

svqueue = gamedata['svlist'][int(numSV)]['queue']
logValue("First video in svqueue: ", svqueue[0])

sourcevideo = gamedata['svlist'][int(numSV)]['queue'][0]
# CCW in degrees
videorotation = int(gamedata['svlist'][int(numSV)]['videorotation'])

logValue("Sourcevideo: ", sourcevideo)
logValue("Video Rotation: ", videorotation)

for controllertype in gamedata['controllertype']:
    logValue("Joystick Controller", controllertype)

numcontrolleraxes = gamedata['controllertype'][0]['axes']
triggertype = gamedata['controllertype'][0]['triggertype']

gamedetails = gamedata['config'][numgame]

# input("hit any key")

##########
# Set PLAYBACK OFF (RECORD) or ON (PLAYBACK EDL)
##########

playmode = gamedata['mode'][0]['playback']

#
quitmode = gamedata['mode'][0]['quit']

# just show every X frame for speed editing. Won't work on 4K w/o GPU # CK
playbackspeed = gamedata['mode'][0]['editspeed']

###########################################################
# set source and destination video files
# EDIT planb_config.json
###########################################################

# set the H:W ratio - for example 1080P HD 1920:1080 Height:Width
# this is a constant. Can't be changed during job
# D720P = (1280, 720)
# D1080P = (1920, 1080)
# D4K = (3840, 2160)
outHW = tuple(gamedata['mode'][0]['destinationvideo'])
logValue("HD HW", outHW)

logValue(f'Playback Value: {playmode}', f'Quit mode: {quitmode}')

destvideo = gamedata['destvideo'][0]['file']

inEDL = gamedata['EDL'][0]['in']
outEDL = gamedata['EDL'][0]['out']

logValue('Destination Video: ', destvideo)
logValue('inEDL: ', inEDL)
logValue('outEDL: ', outEDL)


# set the H:W ratio - for example 1080P HD 1920:1080 Height:Width
# this is a constant. Can't be changed during job
# outHW = D1080P

########## EDIT DECISION LIST
# there are two EDL files
# every job creates edit_decision_list which logs all actions
# if a job is replaying action from a file to cut another file (replay=="ON")
# then we are opening a second EDL (inEDL) as well to get the actions
##########

if playmode == 'ON':  # load up the JSON file. Could be 2MB or so.
    with open(inEDL) as f1:
        inEDLactions = json.load(f1)

    # confirm EDL file has opened and quickly print out first 10 action sequences DEBUG
    for countseq in range(10):  # show first 10 logged sequence records
        csstr = str(countseq)
        if csstr in inEDLactions:
            logValue(csstr, inEDLactions[csstr][0])

    if quitmode == True:
        exitApp()

else:
    logValue('Playmode', 'OFF - create log, no playback')

# create a new EDL file to record actions. Could mirror much of the input EDL!
if os.path.isfile(outEDL):
    with open(outEDL) as f1:
        outEDLactions = json.load(f1)
else:
    outEDLData = {}
    with open(outEDL, 'w') as outfile:
        json.dump(outEDLData, outfile)

# !!! move to loop - eventually. needed here for now.
vidcap = cv2.VideoCapture(sourcevideo)
success, image = vidcap.read()  # vidcap is the sourcefile object. Open file.

# does source video exist?
if success:
    logValue("Source Video", sourcevideo)
    videodatetime = os.path.getctime(sourcevideo)
    videomdatetime = os.path.getmtime(sourcevideo)

else:
    logValue("Source video", f'{sourcevideo} unavailable')
    exitApp()  # that's that.

# Get fps of source video.
fps = (vidcap.get(cv2.CAP_PROP_FPS))

# no film 29.97 film crap. round up to nearest int.
fps = int(round((fps + .1), 0))
logValue("Source Video FPS: ", fps)

# Getting height and width of a source video frame. In pixels.
# channels = colors for each pixel. RGB = 3.
height, width, channels = image.shape


###########################################################
# Variables and constants
# variables all lowercase, constants start with Uppercase
###########################################################

ON = 1
OFF = 0
# continue main frame by frame video loop until false (last frame)
success = True
numloop = 0  # video frame being processed in job. could be multiple video files
numseqout = 0  # sequence number for writing out actions.
numseqin = 0  # sequence number for reading in actions.
numsv = 0
selectspeedup = 1  # interactive user speedup.
numskip = -1  # number of frames to skip on speedup
minX, maxX = 0, width
minY, maxY = 0, height
prevminX = minX
prevminY = minY
prevmaxY = maxY
writeloop = 0
writedump = 30  # dump logs to JSON every 30 changes
zoomscale = 1
zoomunit = 0.03
# zoommax = 1.75
zoommax = 2.5  # for testing. can result in upconversion on zoom depending on source and dest video res
tiltscale = 0
panscale = 0
tiltunit = int(height/180/3)  # !!! clean up later
panunit = int(width/180/3)  # !!! clean up later
awayscore = 0
homescore = 0
paused = False  # vestiage
rewind = False
forward = False
recstate = ON
numforwardframes = 449  # 15sec @ 30fps # this has been replaced by selectspeedup
numrewindframes = 149  # 5sec @ 30fps # !!!  clean up later. Should multiple of fps
shiftUnit = 32  # pixels for keyboard editing.
gamestatus = 0  # pre-game, 1st half, etc.
clkalt = time.time  # current time on the game clock.
currtime = datetime.now()

# for linear camera glide. Divides movement over multiple frames based on
# playbackspeed used during recording.
glideLoop = 0
deltaminY, deltamaxY, deltaminX = 0.0, 0.0, 0.0  # for linear glide

# defaults of the video that was used to create EDL log should be overwritten
editedspeed = 10
editedheight = 1080
editedwidth = 1920
editedfps = 30

# not used right now. Just for information.
if playmode == "ON":
    editedspeed = inEDLactions["editvars"][0]["editspeed"]
    editedheight = inEDLactions["editvars"][0]["editheight"]
    editedwidth = inEDLactions["editvars"][0]["editwidth"]
    editedfps = inEDLactions["editvars"][0]["editfps"]
    logValue("Edited speed", editedspeed)
    logValue("Edited HxW", f'{editedheight}, {editedwidth}')
    logValue("Edited fps", editedfps)

# do again when looping through frames
# numerator = height or width of source video to be cut (typically 4K)
# denominator = height or width of video used to record log (typically 1080P)
xEDLfactor = height/editedheight
yEDLfactor = width/editedwidth

logValue("Source Height, Width", f'H={height}, W= {width}')
logValue("Frame ratio", f'X={xEDLfactor}, Y={yEDLfactor}')

logValue("Number of Source Videos in job: ", len(svlist))

##########
# store time and date of the input video (videosource) in JSON log file.
# for multi video file jobs, we'll need to log each file as loaded.
##########

outEDLData = {}
outEDLData['sourcevideo'] = []

# !!! rework eventually. Just a stub for now.
outEDLData['sourcevideo'].append({
    'seq': "1",  # for eventual ordering of source videos
    'file': sourcevideo,
    'cdate': datetime.fromtimestamp(videodatetime).strftime('%Y-%m-%d'),
    'ctime': datetime.fromtimestamp(videodatetime).strftime('%H:%M:%S'),
    'mdate': datetime.fromtimestamp(videomdatetime).strftime('%Y-%m-%d'),
    'mtime': datetime.fromtimestamp(videomdatetime).strftime('%H:%M:%S')
})

# edited file is being written to the destination video file
outEDLData['destvideo'] = []

outEDLData['destvideo'].append({
    'file': destvideo,
    'date': currtime.strftime('%Y-%m-%d'),
    'time': currtime.strftime('%H:%M:%S'),
    'editspeed': playbackspeed  # just for reference?
})

#
outEDLData['editvars'] = []

outEDLData['editvars'].append({
    'editspeed': playbackspeed,
    'editheight': height,
    'editwidth': width,
    'editfps': fps
})

##########
# create first record in outEDL file
# numseqout starts at 0
# top left corner in OpenCV is 0,0
# minX = upper left corner X (in pixels)
# minY = upper left
# maxY = botton left corner (calculated)
##########

outEDLData[str(numseqout)] = []
outEDLData[str(numseqout)].append({
    'frame': numloop,  # what's the current frame of source video?
    'action': "crop",
    'value': [int(minX * xEDLfactor), int(minY * yEDLfactor), int(height * yEDLfactor)]
    })

# retrieving data from the dict record that was just created. DEBUG
# JSON values will return in dictionary structure
logValue("JSON Test", outEDLData[str(numseqout)])
# coming back in an arroy of 1 element. Getting back just one element, which is a python dictionary.
# example retreiving 1 value
# logValue("JSON Test minX value", logData[str(numseqout)][0]["minX"]) #XX01
logValue("JSON Test Array", outEDLData[str(numseqout)][0]["value"])

numseqout += 1  # move to next sequence number for use with outEDL

# write out the the first JSON record to outEDL file on disk.
with open(outEDL, 'w') as outfile:
    # print("outEDLdata: ", outEDLData)
    # input("Write JSON")
    json.dump(outEDLData, outfile)

##########
# VideoWriter object created using constants set above.
# install H264 .dll from CISCO github. Put in path or place in Python source dir
##########

# delete any existing file with destname to reset OS create time & date
if os.path.exists(destvideo):
    os.remove(destvideo)
    # input(f'File Exists: {destvideo}')
else:
    logValue("Destination file does not exist", destvideo)

#out = cv2.VideoWriter(destvideo, cv2.VideoWriter_fourcc(*'H264'), fps, outHW)


###############################################################################
# Initialize and test the joystick controller(s)
# Constants for controller functions
###############################################################################

# CONSTANTS controller buttons and axes

BLUbutton = 0
GRNbutton = 1
REDbutton = 2
YLWbutton = 3
LTbumper = 4
RTbumper = 5
LTtrigger = 6
RTtrigger = 7
BAKbutton = 8
SRTbutton = 9
LTjoybutton = 10
RTjoybutton = 11

North = (0,  1)
South = (0, -1)
West = (-1, 0)
East = (1,  0)

RTjoystickNS = 3
RTjoystickWE = 2
LTjoystickNS = 1
LTjoystickWE = 0

joystickbuttons = [
    "BLUbutton",
    "GRNbutton",
    "REDbutton",
    "YLWbutton",
    "LTbumper",
    "RTbumper",
    "LTtrigger",
    "RTtrigger",
    "BAKbutton",
    "SRTbutton",
    "LTjoybutton",
    "RTjoybutton"
]

axesdescript = [
    "LTjoystickWE",
    "LTjoystickNS",
    "RTjoystickWE",
    "RTjoystickNS"
]

pygame.init()

# Get count of joysticks. Joystick = entire XBOX controller.
joystick_count = pygame.joystick.get_count()

# For each joystick controller. This shouldn't be more than 1 controller.
for i in range(joystick_count):
    joystick = pygame.joystick.Joystick(i)
    joystick.init()

# a "joystick", really a controller, will have multiple joysticks (axes). 2 on XBOX
# note: it appears on some XBOX contollers, the triggers are a 3rd set of axes
# axes return analog like values. Logitech Gamepad triggers are binary ON/OFF
    axisCount = joystick.get_numaxes()
    axes = np.zeros(axisCount)

    logValue("Num Joysticks", joystick_count)
    logValue("Num Axes", axisCount)

    for i in range(axisCount):
        axes[i] = joystick.get_axis(i)
        logValue(f'Axes #{i}', axes[i])

    buttonCount = joystick.get_numbuttons()
    buttons = np.zeros(buttonCount)
    for i in range(buttonCount):
        buttons[i] = joystick.get_button(i)
        logValue(f'Button #{i}', buttons[i])

    hatCount = joystick.get_numhats()

    controllername = joystick.get_name()

# Hat position. All or nothing (1,0,-1) for direction, not a float
# get_axis(). Position is a tuple of int values (x, y).
    for i in range(hatCount):
        hat = joystick.get_hat(i)
        logValue("Hats Count: ", hatCount)

# Used to manage how fast the screen updates.
clock = pygame.time.Clock()

##########
# DISPLAY JOYSTICK TEST SCREEN
# for Xbox, Logitech
##########

# Set the width and height of the XBOX debug screen
screen = pygame.display.set_mode((350, 550))
screen.fill((255, 0, 0))  # wolfpack red

pygame.display.set_caption("JOYSTICK TEST SCREEN")
# make sure this is in directory
displayfont = pygame.freetype.Font("arial.ttf", 16)
displayValue((10, 30), "XBOX Controller Values", "")
#
# # Loop until the user clicks the close button to close window
done = False

# input("Show panel")

# TEST JOYSTICK OPERATIONS uncomment below
while not done:

    # Possible joystick actions: JOYAXISMOTION, JOYBALLMOTION, JOYBUTTONDOWN,
    # JOYBUTTONUP, JOYHATMOTION
    # Write various controller values to screen and log
    for event in pygame.event.get():  # User did something.
        if event.type == pygame.QUIT:  # If user clicked close box on window.
            done = True  # Flag that we are done so we exit this loop.
            pygame.display.quit()
            break

        else:
            screen.fill((255, 0, 0))
            displayValue((20, 10), controllername, "")
            displayValue((20, 30), "Num Joysticks", joystick_count)
            displayValue((20, 50), "Num Axes", axisCount)
            for i in range(buttonCount):
                buttons[i] = joystick.get_button(i)
                #displayValue((20, 90+(20*i)),
                             #f'[{i}] {joystickbuttons[i]}', buttons[i])

            # input("joystick buttons")
            for i in range(axisCount):
                axes[i] = joystick.get_axis(i)
                #displayValue((20, 340 + (i*20)),
                             #f'[{i}] {axesdescript[i]}', round(axes[i], 2))

            displayValue((20, 440), "Num Hats", hatCount)
            for i in range(hatCount):
                hat = joystick.get_hat(i)
                displayValue((20, 460 + (i*20)), f'Hat [{i}]', hat)

pygame.init()  # re-initialize after closing Joystick test window.

###############################################################################
# BEGIN MAIN LOOP - READ SOURCE FRAME OR INCOMING VIDEO FRAME BY FRAME
# Used for both recording and playing back from log
###############################################################################

########################################
# Put next source video from queue in list
# set variables (height, width, fps, etc) based on source video
########################################

while numsv < len(svqueue):
    sourcevideo = svqueue[numsv]
    gotframeTF = True  # for getting next video frame (used to be "success")
    logValue("Current source video: ", sourcevideo)

    #  vidcap = sourcefile object.
    # image = current frame
    vidcap = cv2.VideoCapture(sourcevideo)
    gotsvTF, image = vidcap.read()

    # does source video exist?
    if gotsvTF:
        logValue("Source Video", sourcevideo)
        videodatetime = os.path.getctime(sourcevideo)
        videomdatetime = os.path.getmtime(sourcevideo)

    else:
        logValue("ERROR: Source video ", f'{sourcevideo} unavailable.')
        exitApp()  # that's that.

    # Get fps of source video.
    fps = int(vidcap.get(cv2.CAP_PROP_FPS))

    # limit fps output to 24. Solves 23.98 film problem.
    fps = max(fps, 24)

    # Getting height and width of a source video frame. In pixels.
    # channels = colors for each pixel. RGB = 3.
    height, width, channels = image.shape
    logValue(f'Source Video {sourcevideo} height, width, channels: ',
             f'{height}, {width}, {channels}')
    logValue("Source Video FPS: ", fps)

    # set sourcefile variables

    tiltunit = int(height/180/3)  # !!!
    panunit = int(width/180/3)  # !!!
    numforwardframes = (15 * fps)  # jump ahead 15-seconds
    numrewindframes = (5 * fps)  # jump back 5-sec

    ########################################
    # process the current source video
    # gotframeTF
    ########################################

    while gotframeTF:  # until current sourcevideo ends # CK

        pygame.event.get()
        nextnumseqin = numseqin + 1  # what is next sequence number to prefetch?

    ##############################
    # PLAYBACK ACTIONS FROM EDL
    ##############################

        if playmode == "ON":  # play back actions from inEDL log!
            playbackspeed = 1  # do not skip frames. Process every frame on playback

            if str(nextnumseqin) in inEDLactions:  # check for next action
                # get frame of next action!
                nextnumloop = inEDLactions[str(nextnumseqin)][0]["frame"]
                nextaction = inEDLactions[str(nextnumseqin)][0]["action"]
                nextvalue = inEDLactions[str(nextnumseqin)][0]["value"]

                logValue(f'Frame: {numloop} Next SEQ: {nextnumseqin}',
                         f' Next numloop: {nextnumloop} Next Action: {nextaction} Next Value {nextvalue}')
            else:
                netnumloop = 1000000  # just run to end of source video

            ############################## # CK
            # IMPLEMENT EDL ACTIONS # CK
            ############################## # CK

            # Is ACTION = CROP coming up? If so break down with glideloop
            if (((numloop + editedspeed) == nextnumloop) and (nextaction == "crop")):  # CK
                glideLoop = editedspeed
                logValue(
                    f'Next Values: frame #{numloop}', inEDLactions[str(nextnumseqin)][0])

                deltaminX = round(
                    (((nextvalue[0])*xEDLfactor-minX)/editedspeed), 2)
                deltaminY = round(
                    (((nextvalue[1])*yEDLfactor-minY)/editedspeed), 2)
                deltamaxY = round(
                    (((nextvalue[2])*yEDLfactor-maxY)/editedspeed), 2)
                logValue("Delta X,Y values",
                         f'{deltaminX}, {deltaminY}, {deltamaxY}')
                numseqin += 1  # move to next sequence & action

            # Linear glide. Camera move broken up over multiple frames
            if glideLoop != 0:
                minY = round((minY + deltaminY), 2)
                minX = round((minX + deltaminX), 2)
                maxY = round((maxY + deltamaxY), 2)
                maxX = round((minX + (1920*((maxY-minY)/1080))), 0)

                logValue("X,Y values", f'{minX}, {minY}, {maxX}, {maxY}')

            if (numloop == nextnumloop):  # CK
                # nextvalue = inEDLactions[str(nextnumseqin)][0]["value"]
                if nextaction == "homescore":  # CK
                    homescore = nextvalue  # CK

                elif nextaction == "awayscore":  # CK
                    awayscore = nextvalue  # CK

                elif nextaction == "awayscorecorrection":  # CK
                    awayscore = nextvalue  # CK

                elif nextaction == "homescorecorrection":  # CK
                    homescore = nextvalue  # CK

                # elif nextaction == "jumprewind":  # CK
                #     numloop = numloop - nextvalue  # CK
                #     vidcap.set(1, numloop)  # CK
                #     logValue("Jumprewind: ", nextvalue)

                elif nextaction == "speedup":  # CK
                    # numloop = numloop + nextvalue  # CK
                    # vidcap.set(1, numloop)  # CK
                    # logValue("Jumpforward: ", nextvalue)
                    selectspeedup = nextvalue
                    logValue("Selectspeedup: ", selectspeedup)

                elif nextaction == "recstate":  # CK
                    recstate = nextvalue  # CK
                    logValue("Recstate: ", recstate)

                elif nextaction == "normalspeed":
                    selectspeedup = 1  # CK

                elif nextaction == "quit":
                    exitApp()  # terminate the job. Save outEDL

                numseqin += 1  # on to next squence # CK

            glideLoop = max((glideLoop - 1), 0)

        ##############################
        # RECORD MANUAL ACTIONS TO EDL
        ##############################

        elif playmode == "OFF":  # record actions to outEDL log
            # Setting the center (where you are zooming too)
            centerX, centerY = width/2, height/2

            # Setting the radius (the amount of zoom)
            radiusX, radiusY = (1/zoomscale)*centerX, (1/zoomscale)*centerY

            # Setting the bounds of our frame using the center and radius
            # Keep in mind - minY is the top of the frame, and maxY is the bottom
            # minX is the left, and maxX is the right
            minX, maxX = int(
                centerX-radiusX+panscale), int(centerX+radiusX+panscale)
            minY, maxY = int(
                centerY-radiusY+tiltscale), int(centerY+radiusY+tiltscale)

            statoutput = str(minX) + "," + str(maxX) + "," + str(minY) + "," + str(maxY) + "\n"
            textEDL.write(statoutput)

            # Cropping our image using our bounds and then resizing it
            if minY <= 0:
                minY = 0
                maxY = int(2*radiusY)
                tiltscale = radiusY-centerY
            elif maxY >= height:
                minY = height-int(2*radiusY)
                maxY = height
                tiltscale = height-radiusY-centerY
            if minX <= 0:
                minX = 0
                maxX = int(2*radiusX)
                panscale = radiusX-centerX
            elif maxX >= width:
                minX = width-int(2*radiusX)
                maxX = width
                panscale = width-radiusX-centerX

        else:
            logValue('Playback not set: ', playmode)
            exitApp()

        if (videorotation == 0) or (playmode == 'OFF'):
            cropped = image[int(minY):int(maxY), int(minX):int(maxX)]  # CK

        else:
            spun = rotateImage(image, videorotation)
            cropped = spun[int(minY):int(maxY), int(minX):int(maxX)]  # CK

        # resized is the size of the final video. Typically 1080P or 720P
        resized = cv2.resize(cropped, outHW)

        ##########
        # Creating top right corner info box
        # Expanded for debugging info. Different depending on playback mode
        ##########

        font = cv2.FONT_HERSHEY_SIMPLEX

        # white box with black 2-pixel boarder
        cv2.rectangle(resized, (10, 10), (230, 250), (255, 255, 255), -1)
        cv2.rectangle(resized, (10, 10), (230, 40), (0, 0, 0), -1)
        cv2.rectangle(resized, (10, 10), (230, 250), (0, 0, 0), 2)

        cv2.putText(resized, gamedetails['event'], (20, 30),
                    font, 0.55, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(resized, gamedetails['hometeam'] + ': '
                    + str(homescore), (20, 60), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
        cv2.putText(resized, gamedetails['awayteam'] + ': ' + str(
            awayscore), (115, 60), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)

        #####################
        # Update Scoreboard
        # Record ACTIONS
        #####################

        if playmode == "OFF":  # show Zoom and crop location
            cv2.putText(resized, 'Zoom: x'+str(round(zoomscale, 2)),
                        (20, 130), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(resized, 'x' + str((selectspeedup-1)*3),
                        (140, 130), font, 0.5, (0, 0, 255), 1, cv2.LINE_AA)

            # is the joystick being recognized in the loop? delete eventually.
            for i in range(axisCount):
                cv2.putText(resized, "Axis " + str(i) + " :" + str(
                    round(axes[i], 2)), (20, (160 + i*20)), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)

            cv2.putText(resized, "x" + str(playbackspeed),
                        (20, 240), font, 0.5, (0, 0, 255), 1, cv2.LINE_AA)

            cv2.putText(resized, "numloop: " + str(numloop),
                        (60, 240), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)

        #####################
        # Update Scoreboard
        # Playback ACTIONS
        #####################

        else:  # show frame, crop coordinates, increments for glide, and zoom.
            cv2.putText(resized, 'Top X,Y: ' + f'{str(round(minX,1))}, {str(round(minY,1))}', (20, 150),
                        font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            # cv2.putText(resized, 'minY:' + str((minY)), (20, 120),
            #            font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(resized, 'Btm X,Y: ' + f'{str(round(maxX,1))}, {str(round(maxY,1))}', (20, 180),
                        font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            # cv2.putText(resized, 'maxY:' + str((maxY)), (20, 180),
            #            font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(resized, 'delta Y:' + str(round((maxY - minY), 1)),
                        (20, 210), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(resized, 'x' + str(round(height/(maxY - minY), 2)),
                        (150, 210), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(resized, 'x' + str((selectspeedup-1)*3),
                        (20, 240), font, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
            cv2.putText(resized, 'frame #' + str(numloop), (100, 240),
                        font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)

        # XXX Note: clock does not work past an hour, must be fixed
        # get all this in a procedure.
        if gamestatus == 0:
            cv2.putText(resized, 'PREGAME', (20, 80), font,
                        0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(resized, '00:00', (114, 80), font,
                        0.5, (0, 0, 0), 1, cv2.LINE_AA)
        elif gamestatus == 1:
            cv2.putText(resized, 'FIRST', (20, 80), font,
                        0.5, (0, 0, 0), 1, cv2.LINE_AA)
            clock = int(time.time()-clkalt)
            if math.floor(clock % 60) < 10 and math.floor(clock/60) < 10:
                cv2.putText(resized, '0'+str(math.floor(clock/60))+':0'+str(clock %
                                                                            60), (114, 80), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            elif math.floor(clock % 60) < 10:
                cv2.putText(resized, str(math.floor(clock/60))+':0'+str(clock %
                                                                        60), (114, 80), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            elif math.floor(clock/60) < 10:
                cv2.putText(resized, '0'+str(math.floor(clock/60))+':'+str(clock %
                                                                           60), (114, 80), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            else:
                cv2.putText(resized, str(math.floor(clock/60))+':'+str(clock %
                                                                       60), (114, 80), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
        elif gamestatus == 2:
            cv2.putText(resized, 'HALFTIME', (20, 80), font,
                        0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(resized, '45:00', (114, 80), font,
                        0.5, (0, 0, 0), 1, cv2.LINE_AA)
        elif gamestatus == 3:
            cv2.putText(resized, 'SECOND', (20, 80), font,
                        0.5, (0, 0, 0), 1, cv2.LINE_AA)
            clock = int(2700+time.time()-clkalt)
            if math.floor(clock % 60) < 10 and math.floor(clock/60) < 10:
                cv2.putText(resized, '0'+str(math.floor(clock/60))+':0'+str(clock %
                                                                            60), (114, 80), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            elif math.floor(clock % 60) < 10:
                cv2.putText(resized, str(math.floor(clock/60))+':0'+str(clock %
                                                                        60), (114, 80), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            elif math.floor(clock/60) < 10:
                cv2.putText(resized, '0'+str(math.floor(clock/60))+':'+str(clock %
                                                                           60), (114, 80), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
            else:
                cv2.putText(resized, str(math.floor(clock/60))+':'+str(clock %
                                                                       60), (114, 80), font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
        elif gamestatus == 4:
            cv2.putText(resized, 'FINAL', (20, 80), font,
                        0.5, (0, 0, 0), 1, cv2.LINE_AA)
            cv2.putText(resized, '90:00', (114, 80), font,
                        0.5, (0, 0, 0), 1, cv2.LINE_AA)

        if recstate == OFF:
            cv2.putText(resized, '||', (200, 80), font,
                        0.5, (0, 0, 255), 1, cv2.LINE_AA)
        else:
            cv2.putText(resized, '*', (200, 80), font,
                        0.75, (0, 0, 255), 1, cv2.LINE_AA)

        # increasing the loop number ie the next frame.
        numloop += 1

        key = cv2.waitKey(1)

        ##########
        # Get all current controller values: joysticks, buttons, hat
        # NOTE: previously there was code here re-initializing the controller
        # Seemed redundant and was causing issues with CK's Logitech controller
        ##########

        axes = np.zeros(axisCount)
        for i in range(axisCount):
            axes[i] = joystick.get_axis(i)

        # print ("Axes:", i, " ", axes[i]) DEBUG

        buttons = np.zeros(buttonCount)
        for i in range(buttonCount):
            buttons[i] = joystick.get_button(i)

        # hatCount = joystick.get_numhats() # axes done before main loop
        # Hat position. All or nothing for direction, not a 0 through 1 value like
        # get_axis(). Position is a tuple of int values (x, y). N,E,S,W
        for i in range(hatCount):
            hat = joystick.get_hat(i)

        # Setting the different key events
        if paused:
            numloop -= playbackspeed
            vidcap.set(1, numloop)

        else:  # Handling pan, tilt, and zoom updating screen
            if axes[RTjoystickNS] <= -0.1 and zoomscale <= round(zoommax-(-1*axes[RTjoystickNS]*zoomunit), 1):
                cv2.putText(resized, 'IN', (20, 110),
                            font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                zoomscale += -1*axes[RTjoystickNS]*zoomunit
            if axes[RTjoystickNS] >= 0.1 and zoomscale >= 1+(axes[RTjoystickNS]*zoomunit):
                cv2.putText(resized, 'OUT', (20, 110),
                            font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                zoomscale -= axes[RTjoystickNS]*zoomunit
            if axes[LTjoystickNS] <= -0.1 and minY >= -1*axes[LTjoystickNS]*tiltunit:
                cv2.putText(resized, 'UP', (90, 110),
                            font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                tiltscale -= -1*axes[LTjoystickNS]*tiltunit
            if axes[LTjoystickNS] >= 0.1 and maxY <= height-(axes[LTjoystickNS]*tiltunit):
                cv2.putText(resized, 'DOWN', (90, 110),
                            font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                tiltscale += axes[LTjoystickNS]*tiltunit
            if axes[LTjoystickWE] <= -0.1 and minX >= -1*axes[LTjoystickWE]*panunit:
                cv2.putText(resized, 'LEFT', (160, 111),
                            font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                panscale -= -1*axes[LTjoystickWE]*panunit
            if axes[LTjoystickWE] >= 0.2 and maxX <= width-(axes[LTjoystickWE]*panunit):
                cv2.putText(resized, 'RIGHT', (160, 111),
                            font, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
                panscale += axes[LTjoystickWE]*panunit

            #########
            # Handling home and away scores
            # CK Logitech controller maps trigger to buttons, not axes
            #########

            # Doesn't work in CK's Logitech triggers.
            # if axes[4] >= 0.8 and prevAxes[4] < 0.8:
            #     awayscore += 1
            # if axes[5] >= 0.8 and prevAxes[5] < 0.8:
            #     homescore += 1

            # Increase home or away score
            if (buttons[RTbumper] == ON and prevButtons[RTbumper] == OFF):  # CK
                awayscore += 1  # CK
                writeValueEDL(numloop, "awayscore", awayscore)  # CK

            if (buttons[LTbumper] == ON and prevButtons[LTbumper] == OFF):  # CK
                homescore += 1  # CK
                writeValueEDL(numloop, "homescore", homescore)  # CK

            # Decrease home or away score
            if (buttons[RTtrigger] == ON and prevButtons[RTtrigger] == OFF) and awayscore >= 1:  # CK
                awayscore -= 1
                writeValueEDL(numloop, "awayscorecorrection", awayscore)  # CK

            if (buttons[LTtrigger] == ON and prevButtons[LTtrigger] == OFF) and homescore >= 1:
                homescore -= 1
                writeValueEDL(numloop, "homescorecorrection", homescore)  # CK

            # Handling game status
            if buttons[GRNbutton] == 1 and gamestatus <= 3 and prevButtons[GRNbutton] == 0:
                gamestatus += 1
                writeValueEDL(numloop, "gamestatus", gamestatus)
            if gamestatus % 2 == 1:
                clkalt = time.time()
            if buttons[REDbutton] == 1 and gamestatus >= 1 and prevButtons[REDbutton] == 0:
                gamestatus -= 1
                writeValueEDL(numloop, "gamestatuscorrection", gamestatus)
            if gamestatus % 2 == 1:
                clkalt = time.time()

        # START button ends program
        if ((buttons[SRTbutton] == 1) or (buttons[BLUbutton] == 1)):
            exitApp()

        # for all hat events, detection is a bit inconsistent. Not sure why.
        if hat == North and prevHat != North:
            selectspeedup = 1
            writeValueEDL(numloop, "normalspeed", "NA")
            clkalt = clock

        # West hat is jumpback 5-seconds. Eventually a series of undos need to be coded.
        if hat == West and prevHat != West:
            rewind = not rewind  # toggle
            if numloop <= numrewindframes:  # don't reset numloop < 0
                numloop = 1
            else:
                numloop -= numrewindframes

            vidcap.set(1, numloop)
            # !!! writeValueEDL(numloop, "jumprewind", numrewindframes)
            # 3/18 not logging jumprewinds for now. Needs to be redone.
            logValue("Jump Rewind to", numloop)

            # move the numseqout count back based on that rewind
            for i in range(2, 100):
                logValue("DEBUG 1077: ", i)
                prevnumloop = prevActionEDL(numseqout - i)
                logValue("DEBUG 1079", prevnumloop)
                logValue(
                    f'DEBUG: {i} | {numseqout-i} | {numloop} and prevnumloop: ', prevnumloop)
                if (numloop <= prevnumloop):
                    logValue(
                        f'DEBUG l084 {i} numloop: {numloop} <', prevnumloop)
                else:
                    numseqout = numseqout - i
                    break

        if hat == East and prevHat != East:
            selectspeedup = selectspeedup + 1
            # forward = not forward
            writeValueEDL(numloop, "speedup", selectspeedup)

        if hat == South and prevHat != South:
            recstate = not recstate
            if recstate == OFF:
                cv2.putText(resized, '||', (200, 80), font,
                            0.5, (0, 0, 255), 1, cv2.LINE_AA)
                writeValueEDL(numloop, "recstate", OFF)
            else:
                cv2.putText(resized, '*', (200, 80), font,
                            0.75, (0, 0, 255), 1, cv2.LINE_AA)
                writeValueEDL(numloop, "recstate", ON)

        # log updated crop box location. Just log changes.
        if not ((minX == prevminX) and (minY == prevminY) and (maxY == prevmaxY)):
            xyset = [int(minX), int(minY), int(maxY)]
            writeValueEDL(numloop, "crop", xyset)

            # append to JSON file on "disk". This could be slow. So just write out every 30 entries
            # honestly, unlikely to be an issue, even on physical drive.
            if (writeloop == writedump):
                with open(outEDL, 'w') as outfile:
                    json.dump(outEDLData, outfile)

                writeloop = 0  # reset of another 30 updates

        prevminX = minX
        prevminY = minY
        prevmaxY = maxY

        # for debouncing
        prevAxes = axes
        prevButtons = buttons
        prevHat = hat

        # Write the frame into the file 'filename.avi'
        # if recstate is OFF (don't record), or we're skipping this frame (numskip != 0) don't record
        adjspeedup = max(((selectspeedup - 1) * 3), 1)
        if (recstate == OFF) or (numskip > 0):  # turn off record with S Hat.
            gotframeTF = cv2.VideoCapture.grab(vidcap)
            numskip -= 1
            # logValue("Current numskip: ", numskip)
        #else:
            #out.write(resized)  # write to file
            # logValue("exec imshow numloop: ", numloop)
        numskip = (playbackspeed * adjspeedup) - 1
        cv2.imshow('Plan B', resized)
        gotframeTF, image = vidcap.read()  # get next frame

    numsv += 1  # next sourcevideo in list

# Finishing up
vidcap.release()
#out.release()
pygame.quit()
cv2.destroyAllWindows()


###############################################################################
# SAMPLE CODE
###############################################################################

##########
# CREATE DICTIONARY OBJECT FOR JSON CONFIG FILE  DEBUG
# Plan B uses configuration file to set various game & event data
# Used for both recording and playing back from EDL filew
# Example on how to write to a JSON file.
##########

# configFile = {}
# configFile['config'] = []
# configFile['mode'] = []

# Write test record to JSON Config File. There will be more data here eventually
# Add & save new event data. Always save, never delete. Use last created record
# should probably include a sequence number here as events are added.
## configFile['config'].append({
##     'event': "Secret COVID Tournament",
##     'hometeam': "Burn",
##     'awayteam': "NCSU",
##     'complex': "Wake Comp Center",
##     'field': "1"
##  })

# create TEST record. Expand to other config values
# if playback == ON, then playback the existing log to edit a video file
## configFile['mode'].append({
##     'playback': "ON",
##     'quit': False

# move these values to different structures. Need UI for data entry.
#    'sourcevideo': "/JBSDEV/python/Source/ABCDrone/video/1080-ult-sample-10.mp4",
#    'destvideo': "s1080P_d720P_10.AVI",
## })

## with open('planb_config.json', 'w') as outfile2:
##     json.dump(configFile, outfile2)
