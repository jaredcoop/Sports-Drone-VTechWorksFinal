from tkinter import *
from PIL import ImageTk, Image
from gameFeedDisplay import *
from updateStats import *
from cutVideo import *
from threading import Thread
import copy

''' 
Buttons:
Stoppage in play -> Resume Play
Start point (only appears after score incremented and disappears when clicked)
Column for roster names (clickable names)
Column next to roster with stat buttons
- throws
- blocks
- error

Logic for recording stats goes: click player name -> click action (ex. "block") -> records in file an entry with timestamp

'''


#root frame
root = Tk()
root.title("ABC Drone Application Controls")
#setting the application root icon
photo = PhotoImage(file="drone.png")
root.iconphoto(False, photo)

greeting = Label(text="Welcome to the ABC Drone Application Control Board")
greeting.pack(padx=50, pady=5)

###################################################################
#Team Variables and score update methods

scoreHome = 0
scoreAway = 0
homeTeam = "Home"
awayTeam = "Away"
action_list = []
disable_buttons = []
stat_file = open('stats.txt', 'w')
edit_file = open('edl.txt', 'w')

def playerAdd(name):
    global action_list, stat_file, edit_file

    print(name)

    if len(action_list) != 1:
        action_list.append(name)

    if len(action_list) == 3 and action_list[1] == 'Throws':
        stat_file.write(action_list[0] + ' ' + action_list[1] + ' ' + action_list[2] + ' ' + str(getFrame()) + '\n')
        updateScores('home', 1, button_play_start)
        action_list.clear()

def actionAdd(action):
    global action_list, stat_file
    print(action)
    if len(action_list) == 1:
        action_list.append(action)

    if len(action_list) == 2 and action_list[1] != 'Throws':
        print(action_list)
        stat_file.write(action_list[0] + ' ' + action_list[1] + ' ' + str(getFrame()) + '\n')
        action_list.clear()

#update scores
def updateScores(team, add_to_score, stoppageButton):
    global scoreHome, scoreAway, homeTeam, awayTeam, stat_file
    if (team == "home"):
        scoreHome = scoreHome + add_to_score
        label_Score_Home.config(text=scoreHome)
        stat_file.write("Score " + homeTeam + " " + str(scoreHome) + ' ' + str(scoreAway) + ' ' + str(getFrame()) + '\n')
    else:
        scoreAway = scoreAway + add_to_score
        label_Score_Away.config(text=scoreAway)
        stat_file.write("Score " + awayTeam + " " + str(scoreHome) + ' ' + str(scoreAway) + ' ' + str(getFrame()) + '\n')
    button_play_start.configure(text="Start of Point", bg="#85fa46", command=lambda: startPlay())
    stoppagePlay()
    updateScoreboard(homeTeam, awayTeam, scoreHome, scoreAway)

        
def updateNames(frame, home, away):
    global homeTeam, awayTeam
    homeTeam = entry_Home.get()
    awayTeam = entry_Away.get()
    button_set_Teams.destroy()
    home.destroy()
    away.destroy()
    label_home = Label(frame, text=homeTeam, padx=10, pady=0, font=("Courier", 24))
    label_home.grid(row=0, column=2, padx=10, pady=5)
    label_away = Label(frame, text=awayTeam, padx=10, pady=0, font=("Courier", 24))
    label_away.grid(row=0, column=4, padx=10, pady=5)
    updateScoreboard(homeTeam, awayTeam, scoreHome, scoreAway)


def stoppagePlay():
    global edit_file
    button_play_start.configure(text="Play Resumed", bg="#85fa46", command=lambda: startPlay())
    edit_file.write("Stop " + str(getFrame()) + '\n')
    for button in disable_buttons:
        button['state'] = DISABLED

def startPlay():
    global edit_file, disable_buttons
    button_play_start.configure(text="Stoppage in Play", bg="#f57a7a", command=lambda: stoppagePlay())
    edit_file.write("Start " + str(getFrame()) + '\n')
    for button in disable_buttons:
        button['state'] = NORMAL

###################################################################
#frame for scoreboard and buttons
frameScore = LabelFrame(root, text="Scoreboard", padx=100, pady=5, borderwidth = 0)
frameScore.pack(padx=10, pady=10)

###################################################################
#Frame for play stoppage buttons
frameStoppage = LabelFrame(root, padx=100, pady=5, borderwidth = 0)
frameStoppage.pack(padx=10, pady=0)

button_play_start = Button(frameStoppage, text="Stoppage in Play", command=lambda: stoppagePlay(), height=1, width=18, bg="#f57a7a")
button_play_start.grid(row=0, column=0, padx=0, pady=0)

###################################################################################################################

# Team Names
entry_Home = Entry(frameScore, textvariable = homeTeam)
entry_Home.insert(END, homeTeam)
entry_Home.grid(row=0, column=2, padx=10, pady=5)

label_VS = Label(frameScore, text="VS")
label_VS.grid(row=0, column=3, padx=10, pady=5)

entry_Away = Entry(frameScore)
entry_Away.insert(END, awayTeam)
entry_Away.grid(row=0, column=4, padx=10, pady=5)


# Scores
# button_Home_Add = Button(frameScore, text="+", command=lambda: updateScores("home", 1, button_play_start)).grid(row=0, column=0, padx=0, pady=0)
button_Away_Add = Button(frameScore, text="+", command=lambda: updateScores("away", 1, button_play_start))
button_Away_Add.grid(row=0, column=6, padx=0, pady=0)
disable_buttons.append(button_Away_Add)

label_Score_Home = Label(frameScore, text=scoreHome, padx=10, pady=0, fg="blue", font=("Courier", 50))
label_Score_Home.grid(row=0, column=1)

label_Score_Away = Label(frameScore, text=scoreAway, padx=10, pady=0, fg="red", font=("Courier", 50))
label_Score_Away.grid(row=0, column=5)


# Set Team Names
button_set_Teams = Button(frameScore, text="Set Teams", command=lambda: updateNames(frameScore, entry_Home, entry_Away))
button_set_Teams.grid(row=1, column=3)
disable_buttons.append(button_set_Teams)

###################################################################
# ROSTER
frameRoster = LabelFrame(root, text="", padx=100, pady=5)
frameRoster.pack(padx=10, pady=10)

label_roster = Label(frameRoster, text="Roster:")
label_roster.grid(row=0, column=0)

# HARD CODED

# bob = Button(frameRoster, text="Bob", height=1, width=10, command=lambda: playerAdd("Bob"))
# joe = Button(frameRoster, text="Joe", height=1, width=10, command=lambda: playerAdd("Joe"))
# steve = Button(frameRoster, text="Steve", height=1, width=10, command=lambda: playerAdd("Steve"))
# connor = Button(frameRoster, text="Connor", height=1, width=10, command=lambda: playerAdd("Connor"))

# bob.grid(row=1, column=0, padx=5, pady=3)
# joe.grid(row=2, column=0, padx=5, pady=3)
# steve.grid(row=3, column=0, padx=5, pady=3)
# connor.grid(row=4, column=0, padx=5, pady=3)

# disable_buttons.append(bob)
# disable_buttons.append(joe)
# disable_buttons.append(steve)
# disable_buttons.append(connor)

rosterFile = open("roster.txt", 'r')
roster = rosterFile.readlines()

r_button_list = []

for i, player in enumerate(roster):
    r_button_list.append(Button(frameRoster, text=player.strip(), height=1, width=10))
    r_button_list[-1].configure(command=lambda x=i: playerAdd(roster[x].strip()))
    r_button_list[-1].grid(row=i+1, column=1, padx=5, pady=3)
    disable_buttons.append(r_button_list[-1])

###################################################################
#Actions

label_actions = Label(frameRoster, text="Actions")
label_actions.grid(row=0, column=10)

actionsFile = open("actions.txt", 'r')
actions = actionsFile.readlines()

a_button_list = []

for i, action in enumerate(actions):
    a_button_list.append(Button(frameRoster, text=action.strip(), height=1, width=10))
    a_button_list[-1].configure(command=lambda x=i: actionAdd(actions[x].strip()))
    a_button_list[-1].grid(row=i+1, column=10, padx=5, pady=3)
    disable_buttons.append(a_button_list[-1])



###################################################################
thread = Thread(target = execute_play_detection)
thread.start()

def on_closing():
    forceQuit()
    root.destroy()
    
    stat_file.close()
    edit_file.close()
    
    cuts = updateStats()
    print(cuts)
    print("from app")
    createCutVideo(cuts)

    

root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()

# takes into account cuts



# off_button = Radiobutton(frameTracking, text="None", variable=sport_variable,indicatoron=False, value="None", width=8, command=sportTypeSwitch)
# soccer_button = Radiobutton(frameTracking, text="Soccer", variable=sport_variable, indicatoron=False, value="Soccer", width=8, command=sportTypeSwitch)
# ultimate_button = Radiobutton(frameTracking, text="Ultimate", variable=sport_variable, indicatoron=False, value="Ultimate", width=8, command=sportTypeSwitch)
# lacrosse_button = Radiobutton(frameTracking, text="Lacrosse", variable=sport_variable,  indicatoron=False, value="Lacrosse", width=8, command=sportTypeSwitch)
# off_button.grid(row=0, column=1)
# soccer_button.grid(row=0, column=2)
# ultimate_button.grid(row=0, column=3)
# lacrosse_button.grid(row=0, column=4)

###################################################################
# #Auto Tracking On Off Switch
# autoTracking = False
# def trackingToggle():
#     global autoTracking
#     if autoTracking:
#         autoTracking = False
#         print("Disabled Auto Tracking")
#         button_Auto_Tracking.configure(bg="#f57a7a")
#         frameTracking.pack_forget()

#     else:
#         autoTracking = True
#         print("Enabled Auto Tracking")
#         button_Auto_Tracking.configure(bg="#85fa46")
#         frameTracking.pack(padx=10, pady=10)
#     toggleAutoTrack()

# button_Auto_Tracking = Button(root, text="Auto Tracking", height=3, width=20, bg="#f57a7a", command=trackingToggle)
# #button_Auto_Tracking.pack(pady=10)

# ###################################################################
# sport_variable = StringVar(value="None")
# def sportTypeSwitch():
#     global sport_variable
#     print("Sport Type Switched to: " + sport_variable.get())
# #Frame for Auto Tracking features
# frameTracking = LabelFrame(root, text="Auto Tracking", padx=100, pady=5)
# #frameTracking.pack(padx=10, pady=10)

# label_Sport_Type = Label(frameTracking, text="Sport Profile:")
# label_Sport_Type.grid(row=0, column=0)